#ifndef _TCPIP_H
#define _TCPIP_H

#include  "ENC28J60.h"

int simple_server(void);

#endif


