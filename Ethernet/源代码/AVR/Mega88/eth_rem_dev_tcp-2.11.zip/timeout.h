/* vim: set sw=8 ts=8 si et: */
#ifndef TOUT_H
#define TOUT_H

extern void delay_ms(unsigned int ms);
extern void wd_init(void);
extern void wd_kick(void);

#endif /* TOUT_H */
